    <div class="container-fluid animatedParent animateOnce my-3">
        <div class="animated fadeInUpShort">

            <div class="card">
                <div class="card-header white">
                    <h6></h6>
                </div>
                <div class="card-body">
                </div>
            </div>

        </div>
    </div>















    
</div>
